# Airlines-Analysis-Hadoop
This Hadoop project involves analysing the airline datasets to solve a few problem statements.


Problem Statements:

1) Find list of Airports operating in the Country India
2) Find the list of Airlines having zero stops
3) List of Airlines operating with code share
4) Which country (or) territory having highest Airports
5) Find the list of Active Airlines in United state

In this use case, there are 3 data sets:

    Final_airlines, routes.dat, airports_mod.dat
