



There are multiple ways to approach this problem such as PIG, Map Reduce algorithms etc.

I'm using the HIVE approach. It's the most popular and widely used approach when it comes to analysing datasets within Hadoop!

Thanks!